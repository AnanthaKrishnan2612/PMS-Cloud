package com.projectmanagementsystem.userservice.model;

public enum CollaborationRole {
    PROJECT_MANAGER, SCRUM_MASTER, MEMBER, EXTERNAL, NO_ACCESS
}
