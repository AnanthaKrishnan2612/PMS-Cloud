export class SubTask{

    public id!:number
        public name!:string;
         public userStoryId!:number;
        public assignedUser!:string;
        public estimatedEfforts!:number;
        public consumedEfforts!:number ;
        public remainingEfforts!:number;
        public status!:string;

}