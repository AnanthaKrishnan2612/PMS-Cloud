export class Project{
    projectName!:string;
    projectType!:string;
}