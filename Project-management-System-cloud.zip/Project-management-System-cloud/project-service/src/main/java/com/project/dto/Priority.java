package com.project.dto;

public enum Priority {
 HIGH,
 LOW,
 MEDIUM
}
