package com.project.model;

public enum UserRole {
    MANAGER, USER
}
