package com.project.model;

public enum CollaborationRole {
    PROJECT_MANAGER, SCRUM_MASTER, MEMBER, EXTERNAL, NO_ACCESS
}
