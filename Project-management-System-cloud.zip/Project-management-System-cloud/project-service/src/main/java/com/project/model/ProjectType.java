package com.project.model;

import lombok.AllArgsConstructor;

public enum ProjectType {
    BUSINESS, SUPPORT
}
