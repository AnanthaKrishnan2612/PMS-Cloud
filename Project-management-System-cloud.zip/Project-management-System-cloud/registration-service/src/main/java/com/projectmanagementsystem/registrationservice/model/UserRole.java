package com.projectmanagementsystem.registrationservice.model;

public enum UserRole {
    MANAGER, USER
}
