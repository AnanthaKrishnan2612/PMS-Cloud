package com.projectmanagementsystem.registrationservice.model;

public enum ProjectType {
    BUSINESS, SUPPORT
}
