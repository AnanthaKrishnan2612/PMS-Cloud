package com.projectmanagementsystem.registrationservice.model;

public enum CollaborationRole {
    PROJECT_MANAGER, SCRUM_MASTER, MEMBER, EXTERNAL, NO_ACCESS
}
